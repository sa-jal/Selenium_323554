package Day8;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Day8.Pages.Home_Page;
import Day8.Pages.Login_Page;
import Day8.Pages.Logout_Page;

public class Test_Pages {
	WebDriver wb;
	Login_Page login;
	Home_Page homepage;
	Logout_Page logout;
	@BeforeClass
	public void launch_browser()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		wb = new ChromeDriver();
		wb.get("http://demowebshop.tricentis.com");
	}
	
	@AfterClass
	public void close_browser()
	{
		wb.close();
	}
  @Test(priority=1)
  public void test_login_page() {
	  login= new Login_Page(wb);
	  login.login("rockerg7@gmail.com","qwerty123");
	  String act_tilte=login.get_title();
	  System.out.println(act_tilte);
	  Assert.assertTrue(act_tilte.contains("Demo Web Shop"));
  }
  
  @Test(priority=2)
  public void test_home_page() {
	  homepage= new Home_Page(wb);
	  String act_tilte=homepage.get_email();
	  System.out.println(act_tilte);
	  Assert.assertTrue(act_tilte.contains("rockerg7@gmail.com"));
  }
  @Test(priority=3)
  public void test_logout()
  {
	  logout = new Logout_Page(wb);
	  logout.click_logout_link();
  }
}
