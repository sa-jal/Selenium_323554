package Day8.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login_Page {
	WebDriver wb;
	By login_link = By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a");
	By e_id = By.xpath("//*[@id=\"Email\"]");
	By password = By.xpath("//*[@id=\"Password\"]");
	By button = By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input");
	
	public Login_Page(WebDriver wb)
	{
		this.wb=wb;
	}
	public void click_login_link() {
		wb.findElement(login_link).click();
	}
	public void set_email(String email)
	{
		wb.findElement(e_id).sendKeys(email);
	}
	public void set_password(String pass)
	{
		wb.findElement(password).sendKeys(pass);
	}
	public void click_login_button() {
		wb.findElement(button).click();
	}
	
	public String get_title() {
		String act_title=wb.getTitle();
		return act_title;
	}
	
	public void login(String email, String pass) {
		click_login_link();
		set_email(email);
		set_password(pass);
		click_login_button();
	}
	
	
	
}
