	package Day8.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Home_Page {
	WebDriver wb;
	By tit = By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a");
	public Home_Page(WebDriver wb)
	{
		this.wb=wb;
	}
	public String get_email() {
		String act_result = wb.findElement(tit).getText();
		return act_result;
	}
	
	
}
