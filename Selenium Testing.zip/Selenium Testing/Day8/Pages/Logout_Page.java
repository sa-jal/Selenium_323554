package Day8.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Logout_Page {
	WebDriver wb;
	By logout_link = By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a");
	public Logout_Page(WebDriver wb)
	{
		this.wb=wb;
	}
	public void click_logout_link() {
		wb.findElement(logout_link).click();
	}
	
	
}
