package test.java.Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Check_out {
	WebDriver wb;
	By fnme=By.xpath("//*[@id=\"first-name\"]");
	By lnme=By.xpath("//*[@id=\"last-name\"]");
	By code=By.xpath("//*[@id=\"postal-code\"]");
	
	public Check_out(WebDriver wb)
	{
		this.wb=wb;
	}
	public void enter_first_name(String fname)
	{
		wb.findElement(fnme).sendKeys(fname);
	}
	public void enter_last_name(String lname)
	{
		wb.findElement(lnme).sendKeys(lname);
	}
	public void zip_code(String zipcode)
	{
		wb.findElement(code).sendKeys(zipcode);
	}
	
	
	
}
