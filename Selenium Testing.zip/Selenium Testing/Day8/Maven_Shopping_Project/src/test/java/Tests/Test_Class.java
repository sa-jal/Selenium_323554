package Tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Test_Class {
	WebDriver wb;
	Home_Page home;
	Add_To_Cart add;
	@BeforeClass
	public void launch_browser()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		wb = new ChromeDriver();
		wb.get("http://www.saucedemo.com");
	}
	
	@Test
  public void test1() {	
	home= new Home_Page(wb);
	add=new Add_To_Cart(wb);
	home.login("standard_user", "secret_sauce");
	add.additem();
	}
}
