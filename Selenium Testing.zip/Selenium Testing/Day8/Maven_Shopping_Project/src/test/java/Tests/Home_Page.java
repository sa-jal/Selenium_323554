package Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Home_Page {
	WebDriver wb;
	By user = By.xpath("//*[@id=\"user-name\"]");
	By password = By.xpath("//*[@id=\"password\"]");
	By clk = By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]");
		public Home_Page(WebDriver wb)
		{
			this.wb=wb;
		}
		public void enter_username(String username)
		{
			wb.findElement(user).sendKeys(username);
		}
		public void enter_password(String pass)
		{
			wb.findElement(password).sendKeys(pass);
		}
		public void click_login()
		{
			wb.findElement(clk).click();
		}
		public void login(String username, String pass) {
			enter_username(username);
			enter_password(pass);
			click_login();
		}
		
}
