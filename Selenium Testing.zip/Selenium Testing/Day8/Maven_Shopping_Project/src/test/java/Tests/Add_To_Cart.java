package Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Add_To_Cart {
	WebDriver wb;
	By bagpack = By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[3]/button");
	By bikelight = By.xpath("//*[@id=\"inventory_container\"]/div/div[2]/div[3]/button");
	By cartlink = By.xpath("//*[@id=\"shopping_cart_container\"]/a");
	By check_btn = By.xpath("//*[@id=\"cart_contents_container\"]/div/div[2]/a[2]");
	public Add_To_Cart(WebDriver wb)
	{
		this.wb=wb;
	}
	public void addbagpack() {
		wb.findElement(bagpack).click();
	}
	public void addbikelight()
	{
		wb.findElement(bikelight).click();
	}
	public void clickcartlink()
	{
		wb.findElement(cartlink).click();
	}
	public void check_out() {
		wb.findElement(check_btn).click();
	}
	public void additem()
	{
		addbagpack();
		addbikelight();
		clickcartlink();
		check_out();
	}
}

