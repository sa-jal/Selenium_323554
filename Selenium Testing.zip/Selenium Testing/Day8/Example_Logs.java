package Day8;


import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Example_Logs {
	Logger log;
	@Test
  public void test1() {
		String exp_result="NOIDA", act_result="NOIDA";
		SoftAssert soft = new SoftAssert();
		soft.assertAll();
		log=Logger.getLogger("devpinoyLogger");
		log.info("TEst 1 executed");
	}
	
	@Test
	  public void test2() {
			String exp_result="NOIDA", act_result="NOIA";
//			SoftAssert soft = new SoftAssert();
//			soft.assertAll();
			
			Assert.assertEquals(act_result, exp_result);
			log=Logger.getLogger("devpinoyLogger");
			log.info("TEst 2 executed");
		}

}
