package Day5;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_And_Logout {
	WebDriver wb;
	ArrayList<Details> al;
	public Login_And_Logout(ArrayList<Details> al)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		wb = new ChromeDriver();
		wb.get("http://demowebshop.tricentis.com");
		this.al=al;
	}
	
	public void login(int i)
	{
		wb.findElement(By.className("ico-login")).click();
		wb.findElement(By.id("Email")).sendKeys(al.get(i-1).email);
		wb.findElement(By.id("Password")).sendKeys(al.get(i-1).pass);
		wb.findElement(By.xpath("//*[@class='button-1 login-button']")).click();
		String act_title;
		act_title=wb.findElement(By.className("account")).getText();
		
		if(act_title.compareTo(al.get(i-1).exp_val)==0)
			al.get(i-1).result="Pass";
		else if(wb.findElement(By.xpath("//*[@class='validation-summary-errors']")).isDisplayed())
		{
			al.get(i-1).result="Pass";
		}else
			al.get(i-1).result="Fail";
		
//		write_excel(wb, result,i);
	
	}
	
	public void logout()
	{
		
	}
}
