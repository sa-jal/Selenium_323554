package Day5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel_To_Site {
	
	File f = new File("C:\\Users\\sajal.gupta1\\workspace\\SeleniumProject\\email.xlsx");
	ArrayList<Details> al = new ArrayList<Details>();
	
	public void read_excel()
	{
		try {
			Details d = new Details();
			FileInputStream fin = new FileInputStream(f);
			XSSFWorkbook w = new XSSFWorkbook(fin);
			XSSFSheet s = w.getSheet("sheet1");
			for(int i=1;i<4;i++)
			{
			XSSFRow r = s.getRow(i);
			XSSFCell c = r.getCell(0);
			d.email = c.getStringCellValue();
			XSSFCell c1 = r.getCell(1);
			d.pass = c1.getStringCellValue();
			XSSFCell c2 = r.getCell(2);
			d.exp_val = c2.getStringCellValue();
			al.add(d);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	

	public void display_read_data()
	{
		for(int i=1;i<4;i++)
		{
			System.out.println(al.get(i-1).email + "   "+al.get(i-1).pass + "   "+al.get(i-1).exp_val + "   "+al.get(i-1).act_val);
		}
	}
	
	public void write_excel(ArrayList<Details> al , int i)
	{
		try {
			FileInputStream fin = new FileInputStream(f);
			XSSFWorkbook w = new XSSFWorkbook(fin);
			XSSFSheet s = w.getSheet("sheet1");
			XSSFRow r = s.getRow(i);
			XSSFCell c = r.createCell(3);
			c.setCellValue(al.get(i-1).result);
			FileOutputStream fout = new FileOutputStream(f);
			w.write(fout);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
