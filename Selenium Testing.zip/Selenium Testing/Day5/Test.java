package Day5;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Excel_To_Site obj = new Excel_To_Site();
		ArrayList<Details> al = new ArrayList<Details>();
			obj.read_excel();
			obj.display_read_data();
			Login_And_Logout obj1 = new Login_And_Logout(al);
			for(int i=1;i<2;i++)
			{
			obj1.login(i);
			}
		}

}
