package Day5;

public class Details {
	String email,pass,exp_val,act_val,result;
	

}
