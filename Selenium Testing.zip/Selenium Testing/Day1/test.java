package Day1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver wb = new ChromeDriver();
		wb.get("https://www.facebook.com");
		wb.findElement(By.id("email")).sendKeys("girishindia@gmail.com");
		wb.findElement(By.id("pass")).sendKeys("newfbp@55");
//		wb.findElement(By.id("loginbutton")).click();
//		String profile_name,title= wb.getTitle();
//		profile_name= wb.findElement(By.xpath("//*[@id=\"u_0_a\"]/div[1]/div[1]/div/a")).getText();
//		System.out.println("title : "+title+ "Profile name :  "+profile_name);
		
//		wb.findElement(By.linkText("Forgotten account?")).click();
//		wb.findElement(By.partialLinkText("Forgott")).click();
//		wb.findElement(By.cssSelector("label#loginbutton")).click();
//		wb.findElement(By.cssSelector("input[type='submit']")).click();
		
		// it is equivalent to above lines 17
//		WebElement we = wb.findElement(By.id("email"));
//		we.sendKeys("girishindia@gmail.com");
		
//		WebElement we1 = wb.findElement(By.id("day"));
//		Select sel= new Select(we1);
//		sel.selectByValue("10");
//		sel.selectByVisibleText("8");
		
		
		
	}


}
