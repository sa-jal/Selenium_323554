package Day1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExampleXpath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver wb = new ChromeDriver();
		wb.get("https://www.facebook.com");
		String s="//*[contains(text(),'Birthday')]";
		System.out.println(wb.findElement(By.xpath(s)).getText());
		
	}

}
