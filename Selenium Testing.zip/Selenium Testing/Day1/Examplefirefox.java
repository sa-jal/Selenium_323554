package Day1;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Examplefirefox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.setProperty("webdriver.ie.driver","D:\\Drivers\\IEDriver.exe");
		System.setProperty("webdriver.gecko.driver","D:\\Drivers\\geckodriver.exe");
//		WebDriver wb = new InternetExplorerDriver();
		WebDriver wb =new FirefoxDriver();
		wb.get("https://www.facebook.com");
	}

}
