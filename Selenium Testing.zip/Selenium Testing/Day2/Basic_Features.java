package Day2;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Basic_Features {
	public void open_site_chrome(String url)
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver wb = new ChromeDriver();
		wb.get(url);
	}
}
