package Day2;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExampleCheckBox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean cs,fs=true;
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver wb = new ChromeDriver();
		wb.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_input_type_checkbox");
//		List<WebE>
		cs = wb.findElement(By.name("vehicle2")).isSelected();
//		if(cs==false)
//		{
//			if(fs==true)
//				wb.findElement(By.name("vehicle2")).click();
//		
//		}
//		else
//		{
//			if(fs==false)
//				wb.findElement(By.name("vehicle2")).click();
//		}
		wb.findElement(By.name("vehicle2")).click();
		wb.findElement(By.linkText("I have a car")).click();
		
	}

}
