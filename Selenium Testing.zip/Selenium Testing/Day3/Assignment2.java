package Day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment2 {

		public void fun()
		{
			System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
			WebDriver wb = new ChromeDriver();
			wb.get("http://examples.codecharge.com/Store/Default.php");
			String exp_title="Online Bookstore",act_title;
			act_title = wb.getTitle();
			if(act_title.compareTo(exp_title)==0)
				System.out.println("Title Verified");
			else
				System.out.println("Title verification Failed");
			WebElement we = wb.findElement(By.name("category_id"));
			Select sc = new Select(we);
			sc.selectByValue("2");
			wb.findElement(By.name("DoSearch")).click();
			wb.close();

		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Assignment2 obj= new Assignment2();
		obj.fun();
			}

}
