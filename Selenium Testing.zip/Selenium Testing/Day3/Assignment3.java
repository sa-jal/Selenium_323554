package Day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver wb = new ChromeDriver();
		wb.get("http://demowebshop.tricentis.com");
		wb.findElement(By.className("ico-login")).click();
		wb.findElement(By.id("Email")).sendKeys("rockerg7@gmail.com");
		wb.findElement(By.id("Password")).sendKeys("qwerty123");
		wb.findElement(By.xpath("//*[@class='button-1 login-button']")).click();
		String exp_title="rockerg7@gmail.com",act_title;
		act_title=wb.findElement(By.className("account")).getText();
		if(act_title.compareTo(exp_title)==0)
			System.out.println("Title Verified");
		else
			System.out.println("Title Verification Failed");
		wb.findElement(By.className("ico-logout")).click();
	}

}
