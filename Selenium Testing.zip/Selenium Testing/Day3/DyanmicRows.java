package Day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DyanmicRows {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver wb = new ChromeDriver();
		wb.get("https://www.w3schools.com/html/html_tables.asp");
		int i=0,j=0;
		for(i=1;i<2;i++)
		{
			for(j=1;j<=3;j++)
			{
				String xp="//*[@id=\"customers\"]/tbody/tr["+i+"]/th["+j+"]";
				String s = wb.findElement(By.xpath(xp)).getText();
				System.out.print(s + "\t\t");
			}
		}
	
		for(i=2;i<=7;i++)
		{
			for(j=1;j<=3;j++)
			{
				String xp="//*[@id=\"customers\"]/tbody/tr["+i+"]/td["+j+"]";
				String s = wb.findElement(By.xpath(xp)).getText();
				System.out.print(s + "\t\t");
			}
			System.out.println();
		}
		
		
	}

	}
