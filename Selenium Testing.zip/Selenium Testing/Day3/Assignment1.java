package Day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment1 {
	public void fun()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver wb = new ChromeDriver();
		wb.get("http://demowebshop.tricentis.com");
		String exp_title="Demo Web Shop",act_title,gender;
		act_title = wb.getTitle();
		if(act_title.compareTo(exp_title)==0)
			System.out.println("Title Verified");
		else
			System.out.println("Title verification Failed");
		wb.findElement(By.className("ico-register")).click();
		String act_reg_title,exp_reg_title="Demo Web Shop. Register";
		act_reg_title = wb.getTitle();
		if(act_reg_title.compareTo(exp_reg_title)==0)
			System.out.println("Registration Title Verified");
		else
			System.out.println("Registration Title verification Failed");
		wb.findElement(By.id("gender-male")).click();
		wb.findElement(By.id("FirstName")).sendKeys("Sajal");
		wb.findElement(By.id("LastName")).sendKeys("Gupta");
		wb.findElement(By.id("Email")).sendKeys("rockerg77@gmail.com");
		wb.findElement(By.id("Password")).sendKeys("qwerty123");
		wb.findElement(By.id("ConfirmPassword")).sendKeys("qwerty123");
		wb.findElement(By.id("register-button")).click();
		wb.findElement(By.xpath("//*[@class='button-1 register-continue-button']")).click();
		wb.findElement(By.className("ico-logout")).click();
		wb.close();

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Assignment1 a = new Assignment1();
		a.fun();
			}

}
