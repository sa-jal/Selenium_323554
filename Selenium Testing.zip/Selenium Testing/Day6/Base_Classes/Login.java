package Day6.Base_Classes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login {
	public String email,pass,act_result;
	WebDriver wb;
	public void open_url(String url)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		wb = new ChromeDriver();
		wb.get(url);
	}
		public String login(String email, String pass, String exp_result, String x)
	{
		open_url("http://demowebshop.tricentis.com");
		wb.findElement(By.className("ico-login")).click();
		wb.findElement(By.id("Email")).sendKeys(email);
		wb.findElement(By.id("Password")).sendKeys(pass);
		wb.findElement(By.xpath("//*[@class='button-1 login-button']")).click();
		act_result=wb.findElement(By.className("account")).getText();
		try
		{
		Boolean b = wb.findElement(By.xpath(x)).isDisplayed();
		if(b)
		{
			System.out.println("Error message displayed");
			String error = wb.findElement(By.xpath(x)).getText();
			System.out.println(error);
			act_result=error;
		}
		}catch(Exception e)
		{
			System.out.println("Login Successful");
		}
		return act_result;
	}
	
		public String login(String email, String pass, String exp_result)
		{
			open_url("http://demowebshop.tricentis.com");
			wb.findElement(By.className("ico-login")).click();
			wb.findElement(By.id("Email")).sendKeys(email);
			wb.findElement(By.id("Password")).sendKeys(pass);
			wb.findElement(By.xpath("//*[@class='button-1 login-button']")).click();
			act_result=wb.findElement(By.className("account")).getText();
			return act_result;
		}
		
		
	public void logout()
	{
		  wb.findElement(By.className("ico-logout")).click();
		  wb.close();
	}
}
