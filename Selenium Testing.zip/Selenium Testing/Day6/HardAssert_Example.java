package Day6;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class HardAssert_Example {
  @Test
  public void test1() {
	  String a="Bank" ,e="Bak";
	  System.out.println("Before");
	// Hard Assert
//	  Assert.assertEquals(a, e);
	  
	  // Soft Assert
	  SoftAssert s = new SoftAssert();
	  s.assertEquals(a, e);
	  System.out.println("Done");
  }
}
