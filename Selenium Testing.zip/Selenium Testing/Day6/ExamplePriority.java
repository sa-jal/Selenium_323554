package Day6;

import org.testng.annotations.Test;

public class ExamplePriority {
  @Test(priority=2)
  public void z() {
	  System.out.println("In z");
  }
  @Test(priority=1)
  public void a() {
	  System.out.println("In a");
  }
  @Test(priority=3)
  public void B() {
	  System.out.println("In B");
  }
  
}
