package Day6;
import Day6.Base_Classes.Login;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Login_Test extends Login {
	String exp_result;
	@Test
  public void test1() {
	  email="rockerg7@gmail.com";
	  pass="qwerty123";
	  exp_result="rockerg7@gmail.com";
	  System.out.println("Inside Test Case 1");
	  this.act_result = login(email, pass, exp_result);
	  Assert.assertEquals(act_result, exp_result);
	  logout();
	}	
	
	@Test
	  public void test2() {
		  email="rockerg7@gmail.com";
		  pass="qwerty123";
		  exp_result="rockerg7676@gmail.com";
		  System.out.println("Inside Test Case 2");
		  this.act_result = login(email, pass, exp_result);
		  Assert.assertEquals(act_result, exp_result);
		  logout();
		}	
		
	
}
