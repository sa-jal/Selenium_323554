package Day6;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExampleAlert{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		WebDriver wb = new ChromeDriver();
		wb.get("http://demo.guru99.com/test/delete_customer.php");
		wb.findElement(By.name("cusid")).sendKeys("32312");
		wb.findElement(By.name("submit")).click();
		Alert a = wb.switchTo().alert();
		System.out.println(a.getText());
		a.accept();
		System.out.println(a.getText());
	}	

}
