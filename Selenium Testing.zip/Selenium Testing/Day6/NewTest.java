package Day6;

import org.testng.annotations.Test;

import Day3.Assignment2;

public class NewTest {
  @Test
  public void test1() {
	  
	  Assignment2 a = new Assignment2();
	  a.fun();
	  System.out.println("1st test case");
  }
  
  public void test2() {
	  System.out.println("1st test case");
  }
//  @Test
//  public void test3() {
//	  System.out.println("3st test case");
//  }
  
}
