package Day6;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Before_After_Class {
	WebDriver wb; 
	
	@BeforeClass
	public void bc()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
			wb = new ChromeDriver();
	}
	
	@AfterClass
	public void ac()
	{
		wb.close();
	}
	@Test
  public void test1() {
		System.out.println("In test1");
	}
}
