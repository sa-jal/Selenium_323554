package Day6;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import Day6.Base_Classes.Login;
public class New_Login_Test extends Login{
	String exp_result;
	WebDriver wb; 
	
	@BeforeClass
	public void bc()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		wb = new ChromeDriver();
	}
	
	@AfterClass
	public void ac()
	{
		wb.close();
	}
	
	@Test
  public void test1() {
			email="rockerg7@gmail.com";
			exp_result= "rockerg7@gmail.com"; 
			pass="qwerty123";
			String x="";
			this.act_result= login(email, pass,exp_result,x );
		    Assert.assertEquals(act_result, exp_result);
		    logout();
 }
	@Test
	  public void test2() {
		email="rockerg7878@gmail.com";
		exp_result= "rockerg7878@gmail.com"; 
		pass="qwerty123";
		String x="/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li";
		this.act_result= login(email, pass,exp_result,x );
		Assert.assertEquals(act_result, exp_result);
	  	logout();
	  }
	@Test
	  public void test3() {
		email="rockerg7@%gmail.com";
		exp_result= "rockerg7@%gmail.com"; 
		pass="qwerty123";
		String x="/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span";
		this.act_result= login(email, pass,exp_result,x );
		Assert.assertEquals(act_result, exp_result);
	  	logout();
	  }
	@Test
	  public void test4() {
		email="rockerg7@gmail.com";
		exp_result= "rockerg7@gmail.com"; 
		pass="qwerty1237373";
		String x="/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li";
		this.act_result= login(email, pass,exp_result,x );
		Assert.assertEquals(act_result, exp_result);
	  	logout();
	  }

}
