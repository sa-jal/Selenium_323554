package Day7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Example_DataProvider_Without_Excel {
  
	
	
	@DataProvider(name="logindata")
	public String[][] getlogindata()
	{
		String logindata[][] = {{"rockerg7@gmail.com","qwerty123","rockerg7@gmail.com"},{"rockerg7@gmail.com","qwerty123","rockerg7876@gmail.com"}};
		return logindata;
	}
	
	
	@Test(dataProvider = "logindata")
  public void login(String email, String pass, String exp_result) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver wb = new ChromeDriver();
		wb.get("http://demowebshop.tricentis.com");
		wb.findElement(By.className("ico-login")).click();
		wb.findElement(By.id("Email")).sendKeys(email);
		wb.findElement(By.id("Password")).sendKeys(pass);
		wb.findElement(By.xpath("//*[@class='button-1 login-button']")).click();
		String act_reult = wb.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		Assert.assertEquals(act_reult, exp_result);
  }
}
