package Day7;

import java.util.ArrayList;

public class Test_Script extends Read_excel{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		All_Web_Elements obj = new All_Web_Elements();
		ArrayList<Web_Elements> al = read_excel();
		for(int i=1 ;i<7;i++)
		{
			switch (al.get(i-1).key) 
			{
			case "launchbrowser":
				obj.launch_browser("http://demowebshop.tricentis.com");
				break;
			case "click":
				obj.click(al.get(i-1).xp);
				break;
			case "entertext" : 
				obj.enter_text(al.get(i-1).xp, al.get(i-1).test_data);
				break;
			case "verify" :
				obj.verify(al.get(i-1).xp, al.get(i-1).test_data, al);
			default:
				break;
			}
		}
		write_excel(al);
		
	}

}
