package Day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class EaxmpleActions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver wb = new ChromeDriver();
		wb.get("http://demowebshop.tricentis.com");
		WebElement we = wb.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[3]/a"));
		Actions act = new Actions(wb);
		Action a1 = act.moveToElement(we).build();
		a1.perform();
		WebElement we1 = wb.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[3]/ul/li[2]/a"));
		Action a2 = act.click(we1).build();
		a2.perform();
	}

}
