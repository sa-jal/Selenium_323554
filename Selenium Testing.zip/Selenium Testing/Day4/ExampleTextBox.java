package Day4;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class ExampleTextBox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver wb = new ChromeDriver();
		wb.get("https://www.facebook.com");
		Actions act = new Actions(wb);
		WebElement we = wb.findElement(By.xpath("//*[@id=\"u_0_l\"]"));
		Action a1 = act.moveToElement(we).click(we).sendKeys("Sajal").keyDown(we,Keys.CONTROL).sendKeys("A").sendKeys("c").keyUp(we,Keys.CONTROL).build();
		a1.perform();
		WebElement we1 = wb.findElement(By.xpath("//*[@id=\"u_0_n\"]"));
		Action a2 = act.moveToElement(we1).click().keyDown(we1,Keys.CONTROL).sendKeys("v").keyUp(we1,Keys.CONTROL).build();
		a2.perform();
		
	}	

}
