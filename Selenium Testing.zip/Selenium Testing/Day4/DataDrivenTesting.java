	package Day4;
	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
	import java.io.IOException;

import org.apache.poi.hssf.dev.ReSave;
import org.apache.poi.xssf.usermodel.XSSFCell;
	import org.apache.poi.xssf.usermodel.XSSFRow;
	import org.apache.poi.xssf.usermodel.XSSFSheet;
	import org.apache.poi.xssf.usermodel.XSSFWorkbook;
	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	public class DataDrivenTesting {

		String email,pass,exp_val,result;
		
		public void read_excel(int i)
		{
			File f = new File("C:\\Users\\sajal.gupta1\\workspace\\SeleniumProject\\email.xlsx");
			try {
				FileInputStream fin = new FileInputStream(f);
				XSSFWorkbook w = new XSSFWorkbook(fin);
				XSSFSheet s = w.getSheet("sheet1");
//				for(int i=1;i<2;i++)
//				{
					XSSFRow r = s.getRow(i);
					XSSFCell c = r.getCell(0);
					email = c.getStringCellValue();
					XSSFCell c1 = r.getCell(1);
					pass = c1.getStringCellValue();
					XSSFCell c2 = r.getCell(2);
					exp_val = c2.getStringCellValue();
//				}
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		public void login_account(WebDriver wb, String email, String pass, int i)
		{
			wb.findElement(By.className("ico-login")).click();
			wb.findElement(By.id("Email")).sendKeys(email);
			wb.findElement(By.id("Password")).sendKeys(pass);
			wb.findElement(By.xpath("//*[@class='button-1 login-button']")).click();
			String act_title;
			act_title=wb.findElement(By.className("account")).getText();
			
			if(act_title.compareTo(exp_val)==0)
				result="Pass";
			else if(wb.findElement(By.xpath("//*[@class='validation-summary-errors']")).isDisplayed())
			{
				result="Pass";
			}else
				result="Fail";
			
			write_excel(wb, result,i);
		}
		
		
		
		public void logout_account(WebDriver wb)
		{
			try {
			wb.findElement(By.className("ico-logout")).click();
		}
			catch (Exception e) {
				// TODO: handle exception
			}
		}
		
		
		
		public void write_excel(WebDriver wb, String result, int i)
		{
			File f = new File("C:\\Users\\sajal.gupta1\\workspace\\SeleniumProject\\email.xlsx");
			try {
				FileInputStream fin = new FileInputStream(f);
				XSSFWorkbook w = new XSSFWorkbook(fin);
				XSSFSheet s = w.getSheet("sheet1");
				XSSFRow r = s.getRow(i);
				XSSFCell c = r.createCell(3);
				c.setCellValue(result);
				FileOutputStream fout = new FileOutputStream(f);
				w.write(fout);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
		
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			DataDrivenTesting a = new DataDrivenTesting();
			System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
			WebDriver wb = new ChromeDriver();
			wb.get("http://demowebshop.tricentis.com");
			
			for(int i=1;i<4;i++)
			{
				a.read_excel(i);
				a.login_account(wb, a.email, a.pass,i);
				if(a.result.compareTo("Pass")==0)
				{
					a.logout_account(wb);
				}
			
		}
			wb.close();
			

	}

}